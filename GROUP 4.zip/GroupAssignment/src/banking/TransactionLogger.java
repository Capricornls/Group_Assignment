package banking;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class TransactionLogger {
    private static final String FILE_NAME = "transactions.txt";
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private TransactionLogger() { }

    public static void log(int accountNumber, String type, double amount, double balance, String message) {
        String record = LocalDateTime.now().format(FORMAT)
                + " | Account: " + accountNumber
                + " | Type: " + type
                + " | Amount: M" + String.format("%.2f", amount)
                + " | Balance: M" + String.format("%.2f", balance)
                + " | Result: " + message;
        append(record);
    }

    public static void logTransfer(int source, int destination, double amount, double sourceBalance, String message) {
        String record = LocalDateTime.now().format(FORMAT)
                + " | Source account: " + source
                + " | Destination account: " + destination
                + " | Type: TRANSFER"
                + " | Amount: M" + String.format("%.2f", amount)
                + " | Source balance: M" + String.format("%.2f", sourceBalance)
                + " | Result: " + message;
        append(record);
    }

    private static void append(String record) {
        try (FileWriter writer = new FileWriter(FILE_NAME, true)) {
            writer.write(record + System.lineSeparator());
        } catch (IOException e) {
            System.out.println("Could not write transaction log: " + e.getMessage());
        }
    }
}
