package banking;

// Abstraction: BankAccount defines shared account data and abstract banking methods.
// Encapsulation: private fields are accessed through getters and controlled methods.
public abstract class BankAccount {
    private final String accountHolder;
    private final int accountNumber;
    private double balance;

    public BankAccount(String accountHolder, int accountNumber, double balance) {
        if (accountHolder == null || accountHolder.trim().isEmpty()) {
            throw new IllegalArgumentException("Account holder cannot be empty.");
        }
        if (accountNumber <= 0) {
            throw new IllegalArgumentException("Account number must be positive.");
        }
        if (!Double.isFinite(balance) || balance < 0) {
            throw new IllegalArgumentException("Opening balance cannot be negative or invalid.");
        }
        this.accountHolder = accountHolder;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public String getAccountHolder() { return accountHolder; }
    public int getAccountNumber() { return accountNumber; }
    public double getBalance() { return balance; }
    protected void setBalance(double balance) {
        if (!Double.isFinite(balance)) {
            throw new IllegalArgumentException("Balance must be a valid number.");
        }
        this.balance = balance;
    }

    public void displayDetails() {
        System.out.println();
        System.out.println("Account holder: " + accountHolder);
        System.out.println("Account number: " + accountNumber);
        System.out.printf("Balance: M%.2f%n", balance);
    }

    public abstract void deposit(double amount);
    public abstract void withdraw(double amount);
    public abstract double calculateInterest();
    public abstract double getOverdraftLimit();
    public abstract double getLoanLimit();
}
