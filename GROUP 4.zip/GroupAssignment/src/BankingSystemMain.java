import banking.BankAccount;
import banking.CurrentAccount;
import banking.Loanable;
import banking.SavingsAccount;
import banking.TransactionLogger;

import java.util.ArrayList;
import java.util.Scanner;

public class BankingSystemMain {
    private static final Scanner input = new Scanner(System.in);
    // Polymorphism: BankAccount references hold SavingsAccount and CurrentAccount objects.
    private static final ArrayList<BankAccount> accounts = new ArrayList<>();

    public static void main(String[] args) {
        addExampleAccounts();
        boolean running = true;

        while (running) {
            showMenu();
            String choiceText = input.nextLine().trim();
            int choice;
            try {
                choice = Integer.parseInt(choiceText);
            } catch (NumberFormatException e) {
                // Exception handling: invalid numeric menu input is caught without terminating the program.
                System.out.println("Please enter a valid whole-number menu choice.");
                TransactionLogger.log(0, "MENU", 0, 0, "FAILED - Invalid numeric input");
                continue;
            }

            if (choice < 1 || choice > 8) {
                System.out.println("Invalid menu choice. Choose 1 to 8.");
                TransactionLogger.log(0, "MENU", 0, 0, "FAILED - Invalid choice: " + choice);
                continue;
            }

            try {
                switch (choice) {
                    case 1: displayAllAccounts(); break;
                    case 2: handleTransaction("DEPOSIT"); break;
                    case 3: handleTransaction("WITHDRAW"); break;
                    case 4: transferMoney(); break;
                    case 5: calculateInterest(); break;
                    case 6: requestLoan(); break;
                    case 7: displayAccountDetails(); break;
                    case 8:
                        running = false;
                        System.out.println("Thank you for using the bank.");
                        break;
                    default: break;
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Operation failed: " + e.getMessage());
                TransactionLogger.log(0, "OPERATION", 0, 0, "FAILED - " + e.getMessage());
            }
        }
        input.close();
    }

    private static void addExampleAccounts() {
        accounts.add(new SavingsAccount("Thabo", 1001, 1500.00));
        accounts.add(new CurrentAccount("Lerato", 1002, 3000.00));
    }

    private static void showMenu() {
        System.out.println("\n===== BANKING SYSTEM =====");
        System.out.println("1. Display All Accounts");
        System.out.println("2. Deposit");
        System.out.println("3. Withdraw");
        System.out.println("4. Transfer");
        System.out.println("5. Calculate Interest");
        System.out.println("6. Request Loan");
        System.out.println("7. Account Details");
        System.out.println("8. Exit");
        System.out.print("Choose option: ");
    }

    private static void displayAllAccounts() {
        for (BankAccount account : accounts) account.displayDetails();
    }

    private static void calculateInterest() {
        BankAccount account = findAccountByNumber();
        if (account == null) return;
        double interest = account.calculateInterest();
        System.out.printf("Interest credited: M%.2f%n", interest);
        TransactionLogger.log(account.getAccountNumber(), "INTEREST",
                interest, account.getBalance(), "SUCCESS");
    }

    private static void displayAccountDetails() {
        BankAccount account = findAccountByNumber();
        if (account != null) account.displayDetails();
    }

    private static BankAccount findAccountByNumber() {
        System.out.print("Enter account number: ");
        String value = input.nextLine().trim();
        int number;
        try {
            number = Integer.parseInt(value);
        } catch (NumberFormatException e) {
            System.out.println("Invalid account number. Enter a whole number.");
            TransactionLogger.log(0, "ACCOUNT SEARCH", 0, 0, "FAILED - Invalid account number");
            return null;
        }

        for (BankAccount account : accounts) {
            if (account.getAccountNumber() == number) return account;
        }
        System.out.println("Account not found.");
        TransactionLogger.log(number, "ACCOUNT SEARCH", 0, 0, "FAILED - Account not found");
        return null;
    }

    private static double readAmount() {
        System.out.print("Enter amount: M");
        String value = input.nextLine().trim();
        try {
            double amount = Double.parseDouble(value);
            if (!Double.isFinite(amount)) throw new NumberFormatException();
            return amount;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Enter a valid numeric amount.");
        }
    }

    private static void handleTransaction(String type) {
        BankAccount account = findAccountByNumber();
        if (account == null) return;
        double amount = 0;
        try {
            amount = readAmount();
            if (type.equals("DEPOSIT")) account.deposit(amount);
            else account.withdraw(amount);
            System.out.println("Transaction successful.");
            TransactionLogger.log(account.getAccountNumber(), type, amount,
                    account.getBalance(), "SUCCESS");
        } catch (IllegalArgumentException e) {
            System.out.println("Transaction failed: " + e.getMessage());
            TransactionLogger.log(account.getAccountNumber(), type, amount,
                    account.getBalance(), "FAILED - " + e.getMessage());
        }
    }

    private static void transferMoney() {
        System.out.println("SOURCE ACCOUNT");
        BankAccount source = findAccountByNumber();
        if (source == null) return;
        System.out.println("DESTINATION ACCOUNT");
        BankAccount destination = findAccountByNumber();
        if (destination == null) {
            TransactionLogger.log(source.getAccountNumber(), "TRANSFER", 0,
                    source.getBalance(), "FAILED - Destination account not found");
            return;
        }

        double amount = 0;
        try {
            amount = readAmount();
            if (source == destination) throw new IllegalArgumentException("Cannot transfer to the same account.");
            if (!Double.isFinite(amount) || amount <= 0) throw new IllegalArgumentException("Transfer amount must be positive.");
            source.withdraw(amount);
            destination.deposit(amount);
            System.out.println("Transfer successful.");
            TransactionLogger.logTransfer(source.getAccountNumber(), destination.getAccountNumber(),
                    amount, source.getBalance(), "SUCCESS; destination balance M" + destination.getBalance());
        } catch (IllegalArgumentException e) {
            System.out.println("Transfer failed: " + e.getMessage());
            TransactionLogger.log(source.getAccountNumber(), "TRANSFER", amount,
                    source.getBalance(), "FAILED - " + e.getMessage());
        }
    }

    private static void requestLoan() {
        BankAccount account = findAccountByNumber();
        if (account == null) return;
        double amount = 0;
        try {
            amount = readAmount();
            ((Loanable) account).requestLoan(amount);
            System.out.println("Loan approved.");
            TransactionLogger.log(account.getAccountNumber(), "LOAN", amount,
                    account.getBalance(), "SUCCESS");
        } catch (IllegalArgumentException e) {
            System.out.println("Loan rejected: " + e.getMessage());
            TransactionLogger.log(account.getAccountNumber(), "LOAN", amount,
                    account.getBalance(), "FAILED - " + e.getMessage());
        }
    }
}
