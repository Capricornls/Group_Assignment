# BIOP2110 Console Banking System

## Requirements
- Java JDK 8 or later
- A terminal or an IDE such as VS Code

## Project structure
- `src/BankingSystemMain.java` — console menu and program entry point
- `src/banking/BankAccount.java` — abstract superclass
- `src/banking/SavingsAccount.java` — savings account
- `src/banking/CurrentAccount.java` — current account
- `src/banking/Loanable.java` — loan interface
- `src/banking/TransactionLogger.java` — timestamped text-file logging
- `transactions.txt` — created/updated when the program records transactions

## Compile and run
Open a terminal in this folder and run:

```bash
javac -d out src/banking/*.java src/BankingSystemMain.java
java -cp out BankingSystemMain
```

The program starts with two sample accounts:
- 1001 — Thabo, Savings Account
- 1002 — Lerato, Current Account

The logger writes `transactions.txt` in the current working directory where the `java` command is run.

## OOP evidence in the code
- Abstraction: `BankAccount` declares abstract banking methods.
- Encapsulation: account state is private; changes occur through validated methods.
- Inheritance: both account classes extend `BankAccount`.
- Polymorphism: the `ArrayList<BankAccount>` stores both account types.
- Overriding: subclasses implement deposits, withdrawals, interest, and display details.
- Interface: both account types implement `Loanable`.
- `final`: `TransactionLogger` is final.
- Exception handling: invalid menu/input and rejected transactions are handled and logged.
